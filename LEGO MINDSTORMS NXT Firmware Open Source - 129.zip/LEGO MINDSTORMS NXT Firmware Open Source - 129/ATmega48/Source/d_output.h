//
// Programmer      
//
// Date init       14.12.2004
//
// Reviser         $Author:: Dktochpe                                        $
//
// Revision date   $Date:: 16-06-05 14:32                                    $
//
// Filename        $Workfile:: d_output.h                                    $
//
// Version         $Revision:: 4                                             $
//
// Archive         $Archive:: /LMS2006/Sys01/Ioctrl/Firmware/Source/d_output $
//
// Platform        C
//


#ifndef   D_OUTPUT
#define   D_OUTPUT

void      dOutputInit(void);
void      dOutputUpdate(UBYTE Brake);
void      dOutputExit(void);

#endif
