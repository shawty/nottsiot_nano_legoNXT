//
// Programmer      
//
// Date init       14.12.2004
//
// Reviser         $Author:: Dkandlun                                        $
//
// Revision date   $Date:: 28-12-04 14:19                                    $
//
// Filename        $Workfile:: d_pccomm.h                                    $
//
// Version         $Revision:: 1                                             $
//
// Archive         $Archive:: /LMS2006/Sys01/Peripheral/Firmware/Source/d_pc $
//
// Platform        C
//


#ifndef   D_PCCOMM
#define   D_PCCOMM

void      dPcCommInit(void);
void      dPcCommExit(void);

#endif
