/* Customer-specific DLib configuration. */
/* Copyright (C) 2003 IAR Systems.  All rights reserved. */

#ifndef _DLIB_CONFIG_H
#define _DLIB_CONFIG_H

/* No changes to the defaults. */

#endif /* _DLIB_CONFIG_H */
