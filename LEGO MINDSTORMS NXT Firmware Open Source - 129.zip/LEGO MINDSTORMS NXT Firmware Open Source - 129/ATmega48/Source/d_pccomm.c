//
// Programmer      
//
// Date init       14.12.2004
//
// Reviser         $Author:: Dktochpe                                        $
//
// Revision date   $Date:: 8-04-05 9:51                                      $
//
// Filename        $Workfile:: d_pccomm.c                                    $
//
// Version         $Revision:: 3                                             $
//
// Archive         $Archive:: /LMS2006/Sys01/Ioctrl/Firmware/Source/d_pccomm $
//
// Platform        C
//

#include  "stdconst.h"
#include  "m_sched.h"
#include  "d_pccomm.h"
#include  "d_pccomm.r"


void      dPcCommInit(void)
{
  //INITPcComm;
}

void      dPcCommExit(void)
{
  //EXITPcComm;
}
