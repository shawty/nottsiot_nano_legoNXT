//
// Programmer      
//
// Date init       14.12.2004
//
// Reviser         $Author:: Dktochpe                                        $
//
// Revision date   $Date:: 28-10-05 13:46                                    $
//
// Filename        $Workfile:: d_button.h                                    $
//
// Version         $Revision:: 3                                             $
//
// Archive         $Archive:: /LMS2006/Sys01/Ioctrl/Firmware/Source/d_button $
//
// Platform        C
//


#ifndef   D_BUTTON
#define   D_BUTTON

void      dButtonInit(void);
void      dButtonUpdate(void);
void      dButtonExit(void);

#endif
